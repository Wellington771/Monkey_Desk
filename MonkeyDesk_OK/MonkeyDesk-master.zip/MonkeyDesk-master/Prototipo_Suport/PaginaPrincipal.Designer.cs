﻿namespace Prototipo_Suport
{
    partial class telaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAndamento = new System.Windows.Forms.Button();
            this.btnPendente = new System.Windows.Forms.Button();
            this.btnAberto = new System.Windows.Forms.Button();
            this.vScrollBar3 = new System.Windows.Forms.VScrollBar();
            this.pnDashboard = new System.Windows.Forms.Panel();
            this.btnFechado = new System.Windows.Forms.Button();
            this.btnResolvido = new System.Windows.Forms.Button();
            this.lbChamados = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbUsuario = new System.Windows.Forms.Label();
            this.btnNovoChamado = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnBuscarChamado = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbAbertos = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.lbAndamento = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.lbPendente = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.lbFechados = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.lbResolvidos = new System.Windows.Forms.Label();
            this.pnMenu = new System.Windows.Forms.Panel();
            this.pbUsuario = new System.Windows.Forms.PictureBox();
            this.pbLupa = new System.Windows.Forms.PictureBox();
            this.pbEstatisticas = new System.Windows.Forms.PictureBox();
            this.pbNovoChamado = new System.Windows.Forms.PictureBox();
            this.pbMonkey = new System.Windows.Forms.PictureBox();
            this.pnAtalho = new System.Windows.Forms.Panel();
            this.pnDashboard.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.pnMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLupa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEstatisticas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNovoChamado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMonkey)).BeginInit();
            this.pnAtalho.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAndamento
            // 
            this.btnAndamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnAndamento.FlatAppearance.BorderSize = 0;
            this.btnAndamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAndamento.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAndamento.ForeColor = System.Drawing.Color.Black;
            this.btnAndamento.Location = new System.Drawing.Point(177, 67);
            this.btnAndamento.Name = "btnAndamento";
            this.btnAndamento.Size = new System.Drawing.Size(146, 50);
            this.btnAndamento.TabIndex = 3;
            this.btnAndamento.Text = "Andamento";
            this.btnAndamento.UseVisualStyleBackColor = false;
            // 
            // btnPendente
            // 
            this.btnPendente.BackColor = System.Drawing.Color.Red;
            this.btnPendente.FlatAppearance.BorderSize = 0;
            this.btnPendente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPendente.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPendente.ForeColor = System.Drawing.Color.Black;
            this.btnPendente.Location = new System.Drawing.Point(342, 67);
            this.btnPendente.Name = "btnPendente";
            this.btnPendente.Size = new System.Drawing.Size(146, 50);
            this.btnPendente.TabIndex = 4;
            this.btnPendente.Text = "Pendente";
            this.btnPendente.UseVisualStyleBackColor = false;
            // 
            // btnAberto
            // 
            this.btnAberto.BackColor = System.Drawing.Color.Lime;
            this.btnAberto.FlatAppearance.BorderSize = 0;
            this.btnAberto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAberto.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAberto.ForeColor = System.Drawing.Color.Black;
            this.btnAberto.Location = new System.Drawing.Point(12, 67);
            this.btnAberto.Name = "btnAberto";
            this.btnAberto.Size = new System.Drawing.Size(146, 50);
            this.btnAberto.TabIndex = 2;
            this.btnAberto.Text = "Aberto";
            this.btnAberto.UseVisualStyleBackColor = false;
            // 
            // vScrollBar3
            // 
            this.vScrollBar3.Location = new System.Drawing.Point(1061, 0);
            this.vScrollBar3.Name = "vScrollBar3";
            this.vScrollBar3.Size = new System.Drawing.Size(20, 542);
            this.vScrollBar3.TabIndex = 1;
            // 
            // pnDashboard
            // 
            this.pnDashboard.BackColor = System.Drawing.Color.White;
            this.pnDashboard.Controls.Add(this.panel17);
            this.pnDashboard.Controls.Add(this.panel18);
            this.pnDashboard.Controls.Add(this.panel6);
            this.pnDashboard.Controls.Add(this.panel2);
            this.pnDashboard.Controls.Add(this.panel1);
            this.pnDashboard.Controls.Add(this.vScrollBar3);
            this.pnDashboard.Location = new System.Drawing.Point(231, 137);
            this.pnDashboard.Name = "pnDashboard";
            this.pnDashboard.Size = new System.Drawing.Size(1085, 516);
            this.pnDashboard.TabIndex = 2;
            // 
            // btnFechado
            // 
            this.btnFechado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnFechado.FlatAppearance.BorderSize = 0;
            this.btnFechado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechado.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechado.ForeColor = System.Drawing.Color.Black;
            this.btnFechado.Location = new System.Drawing.Point(672, 67);
            this.btnFechado.Name = "btnFechado";
            this.btnFechado.Size = new System.Drawing.Size(146, 50);
            this.btnFechado.TabIndex = 5;
            this.btnFechado.Text = "Fechados";
            this.btnFechado.UseVisualStyleBackColor = false;
            // 
            // btnResolvido
            // 
            this.btnResolvido.BackColor = System.Drawing.Color.Cyan;
            this.btnResolvido.FlatAppearance.BorderSize = 0;
            this.btnResolvido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResolvido.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResolvido.ForeColor = System.Drawing.Color.Black;
            this.btnResolvido.Location = new System.Drawing.Point(507, 67);
            this.btnResolvido.Name = "btnResolvido";
            this.btnResolvido.Size = new System.Drawing.Size(146, 50);
            this.btnResolvido.TabIndex = 6;
            this.btnResolvido.Text = "Resolvido";
            this.btnResolvido.UseVisualStyleBackColor = false;
            // 
            // lbChamados
            // 
            this.lbChamados.AutoSize = true;
            this.lbChamados.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbChamados.Location = new System.Drawing.Point(7, 26);
            this.lbChamados.Name = "lbChamados";
            this.lbChamados.Size = new System.Drawing.Size(123, 28);
            this.lbChamados.TabIndex = 7;
            this.lbChamados.Text = "Chamados";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbAbertos);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(7, 53);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(181, 111);
            this.panel1.TabIndex = 2;
            // 
            // lbUsuario
            // 
            this.lbUsuario.AutoSize = true;
            this.lbUsuario.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUsuario.Location = new System.Drawing.Point(70, 215);
            this.lbUsuario.Name = "lbUsuario";
            this.lbUsuario.Size = new System.Drawing.Size(97, 28);
            this.lbUsuario.TabIndex = 12;
            this.lbUsuario.Text = "Usuário";
            // 
            // btnNovoChamado
            // 
            this.btnNovoChamado.BackColor = System.Drawing.Color.White;
            this.btnNovoChamado.FlatAppearance.BorderSize = 0;
            this.btnNovoChamado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovoChamado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovoChamado.ForeColor = System.Drawing.Color.Black;
            this.btnNovoChamado.Location = new System.Drawing.Point(0, 306);
            this.btnNovoChamado.Name = "btnNovoChamado";
            this.btnNovoChamado.Size = new System.Drawing.Size(228, 59);
            this.btnNovoChamado.TabIndex = 8;
            this.btnNovoChamado.Text = "Novo chamado";
            this.btnNovoChamado.UseVisualStyleBackColor = false;
            this.btnNovoChamado.Click += new System.EventHandler(this.btnNovoChamado_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.White;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.Black;
            this.btnDashboard.Location = new System.Drawing.Point(0, 429);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(228, 59);
            this.btnDashboard.TabIndex = 9;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = false;
            // 
            // btnBuscarChamado
            // 
            this.btnBuscarChamado.BackColor = System.Drawing.Color.White;
            this.btnBuscarChamado.FlatAppearance.BorderSize = 0;
            this.btnBuscarChamado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscarChamado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarChamado.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarChamado.Location = new System.Drawing.Point(0, 552);
            this.btnBuscarChamado.Name = "btnBuscarChamado";
            this.btnBuscarChamado.Size = new System.Drawing.Size(228, 59);
            this.btnBuscarChamado.TabIndex = 10;
            this.btnBuscarChamado.Text = "Buscar chamado";
            this.btnBuscarChamado.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Lime;
            this.label3.Location = new System.Drawing.Point(36, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 28);
            this.label3.TabIndex = 16;
            this.label3.Text = "Abertos";
            // 
            // lbAbertos
            // 
            this.lbAbertos.AutoSize = true;
            this.lbAbertos.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAbertos.Location = new System.Drawing.Point(67, 57);
            this.lbAbertos.Name = "lbAbertos";
            this.lbAbertos.Size = new System.Drawing.Size(38, 41);
            this.lbAbertos.TabIndex = 13;
            this.lbAbertos.Text = "0";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.lbAndamento);
            this.panel2.Location = new System.Drawing.Point(435, 53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(181, 111);
            this.panel2.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(79, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 41);
            this.label5.TabIndex = 13;
            this.label5.Text = "0";
            // 
            // lbAndamento
            // 
            this.lbAndamento.AutoSize = true;
            this.lbAndamento.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAndamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lbAndamento.Location = new System.Drawing.Point(23, 16);
            this.lbAndamento.Name = "lbAndamento";
            this.lbAndamento.Size = new System.Drawing.Size(150, 28);
            this.lbAndamento.TabIndex = 16;
            this.lbAndamento.Text = "Andamento";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.lbPendente);
            this.panel6.Location = new System.Drawing.Point(649, 53);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(181, 111);
            this.panel6.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(70, 53);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 41);
            this.label13.TabIndex = 13;
            this.label13.Text = "0";
            // 
            // lbPendente
            // 
            this.lbPendente.AutoSize = true;
            this.lbPendente.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPendente.ForeColor = System.Drawing.Color.Red;
            this.lbPendente.Location = new System.Drawing.Point(30, 16);
            this.lbPendente.Name = "lbPendente";
            this.lbPendente.Size = new System.Drawing.Size(121, 28);
            this.lbPendente.TabIndex = 16;
            this.lbPendente.Text = "Pendente";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.label35);
            this.panel17.Controls.Add(this.lbFechados);
            this.panel17.Location = new System.Drawing.Point(863, 53);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(181, 111);
            this.panel17.TabIndex = 19;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(72, 54);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(38, 41);
            this.label35.TabIndex = 13;
            this.label35.Text = "0";
            // 
            // lbFechados
            // 
            this.lbFechados.AutoSize = true;
            this.lbFechados.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFechados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbFechados.Location = new System.Drawing.Point(29, 17);
            this.lbFechados.Name = "lbFechados";
            this.lbFechados.Size = new System.Drawing.Size(126, 28);
            this.lbFechados.TabIndex = 16;
            this.lbFechados.Text = "Fechados";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label37);
            this.panel18.Controls.Add(this.lbResolvidos);
            this.panel18.Location = new System.Drawing.Point(221, 53);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(181, 111);
            this.panel18.TabIndex = 18;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(69, 54);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(38, 41);
            this.label37.TabIndex = 13;
            this.label37.Text = "0";
            // 
            // lbResolvidos
            // 
            this.lbResolvidos.AutoSize = true;
            this.lbResolvidos.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResolvidos.ForeColor = System.Drawing.Color.Cyan;
            this.lbResolvidos.Location = new System.Drawing.Point(24, 17);
            this.lbResolvidos.Name = "lbResolvidos";
            this.lbResolvidos.Size = new System.Drawing.Size(134, 28);
            this.lbResolvidos.TabIndex = 16;
            this.lbResolvidos.Text = "Resolvidos";
            // 
            // pnMenu
            // 
            this.pnMenu.BackColor = System.Drawing.Color.RoyalBlue;
            this.pnMenu.Controls.Add(this.pbUsuario);
            this.pnMenu.Controls.Add(this.pbLupa);
            this.pnMenu.Controls.Add(this.pbEstatisticas);
            this.pnMenu.Controls.Add(this.lbUsuario);
            this.pnMenu.Controls.Add(this.btnDashboard);
            this.pnMenu.Controls.Add(this.btnBuscarChamado);
            this.pnMenu.Controls.Add(this.pbNovoChamado);
            this.pnMenu.Controls.Add(this.btnNovoChamado);
            this.pnMenu.Location = new System.Drawing.Point(1, 2);
            this.pnMenu.Name = "pnMenu";
            this.pnMenu.Size = new System.Drawing.Size(231, 650);
            this.pnMenu.TabIndex = 8;
            // 
            // pbUsuario
            // 
            this.pbUsuario.Image = global::Prototipo_Suport.Properties.Resources.user;
            this.pbUsuario.Location = new System.Drawing.Point(45, 67);
            this.pbUsuario.Name = "pbUsuario";
            this.pbUsuario.Size = new System.Drawing.Size(138, 127);
            this.pbUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbUsuario.TabIndex = 11;
            this.pbUsuario.TabStop = false;
            // 
            // pbLupa
            // 
            this.pbLupa.Image = global::Prototipo_Suport.Properties.Resources.Lupa;
            this.pbLupa.Location = new System.Drawing.Point(3, 563);
            this.pbLupa.Name = "pbLupa";
            this.pbLupa.Size = new System.Drawing.Size(43, 39);
            this.pbLupa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLupa.TabIndex = 15;
            this.pbLupa.TabStop = false;
            // 
            // pbEstatisticas
            // 
            this.pbEstatisticas.Image = global::Prototipo_Suport.Properties.Resources.estatisticas;
            this.pbEstatisticas.Location = new System.Drawing.Point(3, 447);
            this.pbEstatisticas.Name = "pbEstatisticas";
            this.pbEstatisticas.Size = new System.Drawing.Size(43, 39);
            this.pbEstatisticas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEstatisticas.TabIndex = 14;
            this.pbEstatisticas.TabStop = false;
            // 
            // pbNovoChamado
            // 
            this.pbNovoChamado.Image = global::Prototipo_Suport.Properties.Resources.Novo_Chamado;
            this.pbNovoChamado.Location = new System.Drawing.Point(3, 316);
            this.pbNovoChamado.Name = "pbNovoChamado";
            this.pbNovoChamado.Size = new System.Drawing.Size(43, 39);
            this.pbNovoChamado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNovoChamado.TabIndex = 13;
            this.pbNovoChamado.TabStop = false;
            // 
            // pbMonkey
            // 
            this.pbMonkey.Image = global::Prototipo_Suport.Properties.Resources.MnkeyDeskF;
            this.pbMonkey.Location = new System.Drawing.Point(928, 5);
            this.pbMonkey.Name = "pbMonkey";
            this.pbMonkey.Size = new System.Drawing.Size(138, 127);
            this.pbMonkey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMonkey.TabIndex = 0;
            this.pbMonkey.TabStop = false;
            // 
            // pnAtalho
            // 
            this.pnAtalho.BackColor = System.Drawing.Color.RoyalBlue;
            this.pnAtalho.Controls.Add(this.pbMonkey);
            this.pnAtalho.Controls.Add(this.lbChamados);
            this.pnAtalho.Controls.Add(this.btnAndamento);
            this.pnAtalho.Controls.Add(this.btnPendente);
            this.pnAtalho.Controls.Add(this.btnAberto);
            this.pnAtalho.Controls.Add(this.btnFechado);
            this.pnAtalho.Controls.Add(this.btnResolvido);
            this.pnAtalho.Location = new System.Drawing.Point(219, 2);
            this.pnAtalho.Name = "pnAtalho";
            this.pnAtalho.Size = new System.Drawing.Size(1096, 135);
            this.pnAtalho.TabIndex = 9;
            // 
            // telaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1318, 654);
            this.Controls.Add(this.pnAtalho);
            this.Controls.Add(this.pnMenu);
            this.Controls.Add(this.pnDashboard);
            this.Name = "telaPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.pnDashboard.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.pnMenu.ResumeLayout(false);
            this.pnMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLupa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEstatisticas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNovoChamado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMonkey)).EndInit();
            this.pnAtalho.ResumeLayout(false);
            this.pnAtalho.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pbMonkey;
        private System.Windows.Forms.Button btnAndamento;
        private System.Windows.Forms.Button btnPendente;
        private System.Windows.Forms.Button btnAberto;
        private System.Windows.Forms.VScrollBar vScrollBar3;
        private System.Windows.Forms.Panel pnDashboard;
        private System.Windows.Forms.Button btnFechado;
        private System.Windows.Forms.Button btnResolvido;
        private System.Windows.Forms.Label lbChamados;
        private System.Windows.Forms.PictureBox pbUsuario;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbNovoChamado;
        private System.Windows.Forms.Label lbUsuario;
        private System.Windows.Forms.Button btnNovoChamado;
        private System.Windows.Forms.PictureBox pbEstatisticas;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.PictureBox pbLupa;
        private System.Windows.Forms.Button btnBuscarChamado;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lbFechados;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lbResolvidos;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbPendente;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbAndamento;
        private System.Windows.Forms.Label lbAbertos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnMenu;
        private System.Windows.Forms.Panel pnAtalho;
    }
}

